import xml.etree.ElementTree as ET
import os

path='/root/Downloads/darknet-master/fire-dataset/train/images/'

listdir = os.listdir('annotations')
bdpath = 'labels/'

file=open('train.txt','w')

count=0

for i in listdir:
	
    #count=count+1
    #if(count>5):
        #break
    
    tree = ET.parse('annotations/' + i)
    root = tree.getroot()

    name= root[1].text

    bdfile=open(bdpath + (name.split('.'))[0] + '.txt' ,'w')

    xmin = float(root[6][4][0].text)
    ymin = float(root[6][4][1].text)
    xmax = float(root[6][4][2].text)
    ymax = float(root[6][4][3].text)

    x = ((xmin + xmax)/2 - 1)/xmax
    y = ((ymin + ymax)/2 - 1)/ymax 
    width = (xmax - xmin)/xmax
    height = (ymax - ymin)/ymax

    imgpath = '/content/darknet/firedata/fire-dataset/train/images/' + name + '\n'
    file.write(imgpath)

    txt = '0 ' + str(x) + ' ' + str(y) + ' ' + str(width) + ' ' + str(height) + '\n'

    bdfile.write(txt)
    #print(imgpath)
    #print(txt)

    

    

    

    
